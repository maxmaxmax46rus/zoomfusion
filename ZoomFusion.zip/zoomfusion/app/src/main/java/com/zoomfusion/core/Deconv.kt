package com.zoomfusion.core

import kotlin.math.*

/** Ричардсон–Люси с анти-галлюцинацией по карте покрытия. */
object Deconv {

    fun run(src: FloatArray, w: Int, h: Int, coverage: FloatArray, sharpness: Float): FloatArray {
        val iters = (3 + 12 * sharpness).roundToInt()
        if (iters <= 0) return src
        val k = gauss1d(Params.PSF_SIGMA)
        val out = FloatArray(src.size)
        val covSorted = coverage.clone(); covSorted.sort()
        val m0 = max(1e-4f, covSorted[covSorted.size / 2])
        val strength = 0.35f + 0.65f * sharpness

        for (ch in 0..2) {
            val y = FloatArray(w * h) { src[it * 3 + ch] }
            var x = y.clone()
            val tmp = FloatArray(w * h)
            val ratio = FloatArray(w * h)
            repeat(iters) {
                convSep(x, tmp, w, h, k)
                for (i in ratio.indices) ratio[i] = y[i] / max(tmp[i], 1e-5f)
                convSep(ratio, tmp, w, h, k)
                for (i in x.indices) x[i] = (x[i] * tmp[i]).coerceIn(0f, 24f)
            }
            for (i in x.indices) {
                val a = (coverage[i] / m0).coerceIn(0f, 1f) * strength
                out[i * 3 + ch] = a * x[i] + (1 - a) * y[i]
            }
        }
        return out
    }

    private fun gauss1d(sigma: Float): FloatArray {
        val r = ceil(sigma * 3).toInt()
        val k = FloatArray(2 * r + 1)
        var s = 0f
        for (i in -r..r) { k[i + r] = exp(-0.5f * i * i / (sigma * sigma)); s += k[i + r] }
        for (i in k.indices) k[i] /= s
        return k
    }

    private fun convSep(src: FloatArray, dst: FloatArray, w: Int, h: Int, k: FloatArray) {
        val r = k.size / 2
        val tmp = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            for (i in -r..r) s += src[y * w + (x + i).coerceIn(0, w - 1)] * k[i + r]
            tmp[y * w + x] = s
        }
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            for (i in -r..r) s += tmp[((y + i).coerceIn(0, h - 1)) * w + x] * k[i + r]
            dst[y * w + x] = s
        }
    }
}

/** Lanczos3 — финальный ресемплинг (вход может быть HDR). */
object Resample {
    private fun lanczos(x: Float): Float {
        if (x == 0f) return 1f
        val ax = abs(x); if (ax >= 3f) return 0f
        val px = PI.toFloat() * x
        return 3f * sin(px) * sin(px / 3f) / (px * px)
    }

    fun resize(src: FloatArray, sw: Int, sh: Int, dw: Int, dh: Int): FloatArray {
        val mid = FloatArray(dw * sh * 3)
        val out = FloatArray(dw * dh * 3)
        val sx = sw.toFloat() / dw; val sy = sh.toFloat() / dh
        for (y in 0 until sh) for (x in 0 until dw) {
            val cx = (x + 0.5f) * sx - 0.5f
            val x0 = floor(cx).toInt()
            var ws = 0f; val acc = floatArrayOf(0f, 0f, 0f)
            for (i in x0 - 2..x0 + 3) {
                val wgt = lanczos(cx - i); if (wgt == 0f) continue
                val xi = i.coerceIn(0, sw - 1)
                ws += wgt
                for (c in 0..2) acc[c] += src[(y * sw + xi) * 3 + c] * wgt
            }
            for (c in 0..2) mid[(y * dw + x) * 3 + c] = acc[c] / ws
        }
        for (y in 0 until dh) for (x in 0 until dw) {
            val cy = (y + 0.5f) * sy - 0.5f
            val y0 = floor(cy).toInt()
            var ws = 0f; val acc = floatArrayOf(0f, 0f, 0f)
            for (i in y0 - 2..y0 + 3) {
                val wgt = lanczos(cy - i); if (wgt == 0f) continue
                val yi = i.coerceIn(0, sh - 1)
                ws += wgt
                for (c in 0..2) acc[c] += mid[(yi * dw + x) * 3 + c] * wgt
            }
            for (c in 0..2) out[(y * dw + x) * 3 + c] = max(0f, acc[c] / ws)
        }
        return out
    }
}

/**
 * Финишная обработка «как у Pixel»: сначала чистим, потом точим.
 *  linear():  CCM -> авто-баланс серого -> Рейнхард (HDR) -> растяжка точек
 *  display(): гамма -> люма-шумодав (вейвлет-порог с MAD-автокалибровкой)
 *             -> clarity (локальный контраст) -> unsharp с клампом гало
 *             -> хрома-шумодав -> контраст -> насыщенность
 */
object Finish {

    private val DEFAULT_CCM = floatArrayOf(
        1.65f, -0.45f, -0.20f,
        -0.30f, 1.70f, -0.40f,
        -0.05f, -0.55f, 1.60f
    )

    fun linear(rgb: FloatArray, ccmIn: FloatArray?): FloatArray {
        val ccm = ccmIn ?: DEFAULT_CCM
        val n = rgb.size / 3
        val out = FloatArray(rgb.size)
        for (i in 0 until n) {
            val r = rgb[i * 3]; val g = rgb[i * 3 + 1]; val b = rgb[i * 3 + 2]
            out[i * 3]     = max(0f, ccm[0] * r + ccm[1] * g + ccm[2] * b)
            out[i * 3 + 1] = max(0f, ccm[3] * r + ccm[4] * g + ccm[5] * b)
            out[i * 3 + 2] = max(0f, ccm[6] * r + ccm[7] * g + ccm[8] * b)
        }
        autoWhite(out)
        val lum = FloatArray(n) { 0.2126f * out[it * 3] + 0.7152f * out[it * 3 + 1] + 0.0722f * out[it * 3 + 2] }
        val lw = max(1.0f, percentile(lum, 0.999f))
        for (i in 0 until n) {
            val l = lum[i]
            if (l > 1e-6f) {
                val ld = l * (1 + l / (lw * lw)) / (1 + l)
                val sc = ld / l
                out[i * 3] *= sc; out[i * 3 + 1] *= sc; out[i * 3 + 2] *= sc
            }
        }
        val lum2 = FloatArray(n) { 0.2126f * out[it * 3] + 0.7152f * out[it * 3 + 1] + 0.0722f * out[it * 3 + 2] }
        val black = percentile(lum2, 0.004f)
        val white = max(black + 1e-3f, percentile(lum2, 0.997f))
        val inv = 0.97f / (white - black)
        for (i in out.indices) out[i] = ((out[i] - black) * inv).coerceIn(0f, 1f)
        return out
    }

    /** Мягкий gray-world по средним тонам: убирает цветовой налёт, клампы ±18%. */
    private fun autoWhite(rgb: FloatArray) {
        val n = rgb.size / 3
        var sr = 0.0; var sg = 0.0; var sb = 0.0; var cnt = 0
        val step = max(1, n / 200_000)
        var i = 0
        while (i < n) {
            val r = rgb[i * 3]; val g = rgb[i * 3 + 1]; val b = rgb[i * 3 + 2]
            val l = 0.2126f * r + 0.7152f * g + 0.0722f * b
            if (l in 0.08f..0.9f) { sr += r; sg += g; sb += b; cnt++ }
            i += step
        }
        if (cnt < 100) return
        val gr = (sg / max(sr, 1e-6)).toFloat().coerceIn(0.82f, 1.18f)
        val gb = (sg / max(sb, 1e-6)).toFloat().coerceIn(0.82f, 1.18f)
        for (j in 0 until n) { rgb[j * 3] *= gr; rgb[j * 3 + 2] *= gb }
    }

    fun display(rgb: FloatArray, w: Int, h: Int, s: ProcSettings): FloatArray {
        val n = w * h
        // гамма sRGB
        for (i in rgb.indices) {
            val v = rgb[i]
            rgb[i] = if (v <= 0.0031308f) 12.92f * v else 1.055f * v.pow(1f / 2.4f) - 0.055f
        }
        // разделяем люму и цветоразности
        val l = FloatArray(n); val cb = FloatArray(n); val cr = FloatArray(n)
        for (i in 0 until n) {
            val r = rgb[i * 3]; val g = rgb[i * 3 + 1]; val b = rgb[i * 3 + 2]
            l[i] = 0.299f * r + 0.587f * g + 0.114f * b
            cb[i] = b - l[i]; cr[i] = r - l[i]
        }
        lumaDenoise(l, w, h, s.denoise)
        clarity(l, w, h, 0.10f + 0.22f * s.contrast)
        unsharp(l, w, h, 0.25f + 0.95f * s.sharpness)
        if (s.denoise > 0.05f) {
            val rad = 2 + (5 * s.denoise).toInt()
            boxBlur(cb, w, h, rad); boxBlur(cr, w, h, rad)
        }
        // сборка обратно
        for (i in 0 until n) {
            val rr = (l[i] + cr[i]).coerceIn(0f, 1f)
            val bb = (l[i] + cb[i]).coerceIn(0f, 1f)
            val gg = ((l[i] - 0.299f * rr - 0.114f * bb) / 0.587f).coerceIn(0f, 1f)
            rgb[i * 3] = rr; rgb[i * 3 + 1] = gg; rgb[i * 3 + 2] = bb
        }
        // контраст: базовый панч + слайдер
        val c = 0.08f + (s.contrast - 0.5f) * 1.4f
        if (abs(c) > 1e-3f) for (i in rgb.indices) {
            val v = rgb[i]
            val sc = v * v * (3 - 2 * v)
            rgb[i] = (v + c * (sc - v)).coerceIn(0f, 1f)
        }
        // насыщенность
        val sat = 0.4f + 1.2f * s.saturation
        for (i in 0 until n) {
            val r = rgb[i * 3]; val g = rgb[i * 3 + 1]; val b = rgb[i * 3 + 2]
            val ll = 0.299f * r + 0.587f * g + 0.114f * b
            rgb[i * 3]     = (ll + (r - ll) * sat).coerceIn(0f, 1f)
            rgb[i * 3 + 1] = (ll + (g - ll) * sat).coerceIn(0f, 1f)
            rgb[i * 3 + 2] = (ll + (b - ll) * sat).coerceIn(0f, 1f)
        }
        return rgb
    }

    /**
     * Люма-шумодав: два масштаба высоких частот + мягкий порог.
     * Порог калибруется по самому кадру через MAD — модель шума не нужна.
     */
    private fun lumaDenoise(l: FloatArray, w: Int, h: Int, den: Float) {
        if (den < 0.03f) return
        val b1 = l.clone(); boxBlur(b1, w, h, 1)
        val b2 = b1.clone(); boxBlur(b2, w, h, 2)
        val n = l.size
        val h1 = FloatArray(n) { l[it] - b1[it] }
        val h2 = FloatArray(n) { b1[it] - b2[it] }
        val t1 = (0.6f + 2.8f * den) * mad(h1)
        val t2 = (0.3f + 1.6f * den) * mad(h2)
        for (i in 0 until n)
            l[i] = (b2[i] + soft(h1[i], t1) + soft(h2[i], t2)).coerceIn(0f, 1f)
    }

    private fun soft(x: Float, t: Float) = when { x > t -> x - t; x < -t -> x + t; else -> 0f }

    /** Робастная оценка сигмы шума: 1.4826 * медиана |highpass|. */
    private fun mad(a: FloatArray): Float {
        val step = max(1, a.size / 60_000)
        val s = FloatArray((a.size + step - 1) / step)
        var j = 0; var i = 0
        while (i < a.size) { s[j++] = abs(a[i]); i += step }
        s.sort()
        return 1.4826f * s[s.size / 2] + 1e-6f
    }

    /** Локальный контраст: возвращает фактуру фона (стекло, стены, ткань). */
    private fun clarity(l: FloatArray, w: Int, h: Int, amount: Float) {
        val big = l.clone(); boxBlur(big, w, h, 18); boxBlur(big, w, h, 18)
        for (i in l.indices) {
            val d = (amount * (l[i] - big[i])).coerceIn(-0.2f, 0.2f)
            l[i] = (l[i] + d).coerceIn(0f, 1f)
        }
    }

    /** Финальная резкость с клампом дельты — резко, но без гало как у пережатых SR. */
    private fun unsharp(l: FloatArray, w: Int, h: Int, amount: Float) {
        val b = l.clone(); boxBlur(b, w, h, 1)
        for (i in l.indices) {
            val d = (amount * (l[i] - b[i])).coerceIn(-0.13f, 0.13f)
            l[i] = (l[i] + d).coerceIn(0f, 1f)
        }
    }

    /** Бокс-блюр скользящим окном: O(1) на пиксель при любом радиусе. */
    private fun boxBlur(d: FloatArray, w: Int, h: Int, r: Int) {
        val tmp = FloatArray(w * h)
        val inv = 1f / (2 * r + 1)
        for (y in 0 until h) {
            val row = y * w
            var acc = 0f
            for (k in -r..r) acc += d[row + k.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[row + x] = acc * inv
                val add = (x + r + 1).coerceAtMost(w - 1)
                val sub = (x - r).coerceAtLeast(0)
                acc += d[row + add] - d[row + sub]
            }
        }
        for (x in 0 until w) {
            var acc = 0f
            for (k in -r..r) acc += tmp[(k.coerceIn(0, h - 1)) * w + x]
            for (y in 0 until h) {
                d[y * w + x] = acc * inv
                val add = (y + r + 1).coerceAtMost(h - 1)
                val sub = (y - r).coerceAtLeast(0)
                acc += tmp[add * w + x] - tmp[sub * w + x]
            }
        }
    }

    private fun percentile(a: FloatArray, p: Float): Float {
        val step = max(1, a.size / 100_000)
        val sample = FloatArray((a.size + step - 1) / step)
        var j = 0; var i = 0
        while (i < a.size) { sample[j++] = a[i]; i += step }
        sample.sort()
        return sample[(sample.size * p).toInt().coerceIn(0, sample.size - 1)]
    }
}
