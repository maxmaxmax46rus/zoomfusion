package com.zoomfusion

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Surface
import android.view.TextureView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.zoomfusion.camera.BurstCaptureController
import com.zoomfusion.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    private var controller: BurstCaptureController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }

    override fun onDestroy() {
        controller?.close()
        super.onDestroy()
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun App() {
        val ctx = LocalContext.current
        val scheme = if (Build.VERSION.SDK_INT >= 31) dynamicDarkColorScheme(ctx) else darkColorScheme()

        MaterialTheme(colorScheme = scheme) {
            var s by remember { mutableStateOf(ProcSettings()) }
            var status by remember { mutableStateOf("Запуск камеры…") }
            var busy by remember { mutableStateOf(false) }
            var lastShot by remember { mutableStateOf<Bitmap?>(null) }
            var showSheet by remember { mutableStateOf(false) }
            var showFull by remember { mutableStateOf(false) }
            var surfaceReady by remember { mutableStateOf(false) }
            var texView by remember { mutableStateOf<TextureView?>(null) }
            val scope = rememberCoroutineScope()

            var granted by remember {
                mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA)
                        == PackageManager.PERMISSION_GRANTED)
            }
            val permLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()) { granted = it }
            LaunchedEffect(Unit) { if (!granted) permLauncher.launch(Manifest.permission.CAMERA) }

            LaunchedEffect(granted, surfaceReady) {
                if (granted && surfaceReady && controller == null) {
                    try {
                        val c = BurstCaptureController(ctx)
                        c.open(Surface(texView!!.surfaceTexture!!))
                        controller = c
                        c.setPreviewZoom(s.zoom)
                        status = if (c.isTele) "Телевик 5x • RAW • готово"
                                 else "Главный сенсор • RAW • готово"
                    } catch (e: Exception) { status = "Ошибка камеры: ${e.message}" }
                }
            }
            LaunchedEffect(s.zoom) { controller?.setPreviewZoom(s.zoom) }

            Box(Modifier.fillMaxSize().background(Color.Black)) {
                // ---- превью камеры ----
                androidx.compose.ui.viewinterop.AndroidView(
                    factory = { c ->
                        TextureView(c).apply {
                            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                                    st.setDefaultBufferSize(1280, 960); surfaceReady = true
                                }
                                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                                override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
                                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                            }
                            texView = this
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // ---- статус ----
                Surface(
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 48.dp)
                ) {
                    Text(status, Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        style = MaterialTheme.typography.labelLarge)
                }

                // ---- нижняя панель ----
                Column(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (s.mode != CamMode.PHOTO) {
                        Surface(
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.55f),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier.padding(horizontal = 24.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 16.dp)) {
                                Text("${"%.0f".format(s.zoom)}×",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary)
                                Slider(
                                    value = s.zoom, onValueChange = { s = s.copy(zoom = it) },
                                    valueRange = 5f..30f, enabled = !busy,
                                    modifier = Modifier.width(220.dp).padding(start = 8.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                    }

                    ModeRow(s.mode, enabled = !busy) { m ->
                        s = when (m) {
                            CamMode.PHOTO -> s.copy(mode = m, zoom = 5f)
                            CamMode.NIGHT -> s.copy(mode = m, frames = 24)
                            else -> s.copy(mode = m)
                        }
                    }
                    Spacer(Modifier.height(14.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // миниатюра последнего кадра
                        Box(Modifier.size(56.dp).clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable(lastShot != null) { showFull = true }) {
                            lastShot?.let {
                                Image(it.asImageBitmap(), null,
                                    Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            }
                        }
                        Spacer(Modifier.width(28.dp))
                        Shutter(busy) {
                            val ctl = controller ?: return@Shutter
                            scope.launch {
                                busy = true
                                try {
                                    status = "Серия ${s.frames} RAW…"
                                    val data = ctl.captureBurst(s)
                                    val bmp = Pipeline.process(data, s) { m -> status = m }
                                    save(bmp)
                                    lastShot = bmp
                                    status = "Сохранено в галерею"
                                } catch (e: Exception) {
                                    status = "Ошибка: ${e.message}"
                                } finally { busy = false }
                            }
                        }
                        Spacer(Modifier.width(28.dp))
                        FilledTonalIconButton(onClick = { showSheet = true },
                            enabled = !busy, modifier = Modifier.size(56.dp)) {
                            Text("⚙", style = MaterialTheme.typography.titleLarge)
                        }
                    }
                }

                if (showSheet) {
                    ModalBottomSheet(onDismissRequest = { showSheet = false }) {
                        SettingsSheet(s) { s = it }
                    }
                }
                if (showFull && lastShot != null) {
                    Dialog(onDismissRequest = { showFull = false }) {
                        Image(lastShot!!.asImageBitmap(), null,
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                                .clickable { showFull = false })
                    }
                }
            }
        }
    }

    @Composable
    fun ModeRow(mode: CamMode, enabled: Boolean, onSelect: (CamMode) -> Unit) {
        val labels = listOf(
            CamMode.PHOTO to "Фото", CamMode.ZOOM to "Зум",
            CamMode.HDR to "HDR", CamMode.NIGHT to "Ночь"
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            labels.forEach { (m, label) ->
                val sel = mode == m
                val bg by animateColorAsState(
                    if (sel) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surface.copy(alpha = 0.55f),
                    label = "mode-bg"
                )
                Surface(color = bg, shape = RoundedCornerShape(50),
                    modifier = Modifier.clickable(enabled) { onSelect(m) }) {
                    Text(label,
                        Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        color = if (sel) MaterialTheme.colorScheme.onPrimaryContainer
                                else MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }

    @Composable
    fun Shutter(busy: Boolean, onClick: () -> Unit) {
        val sc by animateFloatAsState(if (busy) 0.82f else 1f, spring(), label = "shutter")
        Box(contentAlignment = Alignment.Center) {
            if (busy) CircularProgressIndicator(Modifier.size(92.dp), strokeWidth = 3.dp)
            Box(Modifier.size(80.dp).scale(sc).clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
                .border(4.dp, MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.35f), CircleShape)
                .clickable(!busy, onClick = onClick))
        }
    }

    @Composable
    fun SettingsSheet(s: ProcSettings, onChange: (ProcSettings) -> Unit) {
        Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp)
            .verticalScroll(rememberScrollState())) {
            Text("Обработка", style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            LabeledSlider("Шумоподавление", s.denoise, 0f..1f) { onChange(s.copy(denoise = it)) }
            LabeledSlider("Резкость", s.sharpness, 0f..1f) { onChange(s.copy(sharpness = it)) }
            LabeledSlider("Контраст", s.contrast, 0f..1f) { onChange(s.copy(contrast = it)) }
            LabeledSlider("Насыщенность", s.saturation, 0f..1f) { onChange(s.copy(saturation = it)) }
            LabeledSlider("Экспозиция  ${"%+.1f".format(s.evComp)} EV", s.evComp, -2f..2f) {
                onChange(s.copy(evComp = it))
            }
            LabeledSlider("Кадров в серии: ${s.frames}", s.frames.toFloat(), 8f..24f) {
                onChange(s.copy(frames = it.toInt()))
            }
            if (s.mode == CamMode.HDR)
                LabeledSlider("Ступеней HDR: ${s.hdrStops}", s.hdrStops.toFloat(), 1f..5f) {
                    onChange(s.copy(hdrStops = it.toInt()))
                }

            Spacer(Modifier.height(8.dp))
            Text("Метод склейки", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MethodChip("Ядровая", s.method == MergeMethod.KERNEL) {
                    onChange(s.copy(method = MergeMethod.KERNEL)) }
                MethodChip("Среднее", s.method == MergeMethod.ROBUST_MEAN) {
                    onChange(s.copy(method = MergeMethod.ROBUST_MEAN)) }
                MethodChip("Медиана", s.method == MergeMethod.MEDIAN) {
                    onChange(s.copy(method = MergeMethod.MEDIAN)) }
            }
            Spacer(Modifier.height(12.dp))
            Text("Ядровая регрессия — максимум детализации; среднее — мягче и чище; " +
                 "медиана — для сцен с движением.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    @Composable
    @OptIn(ExperimentalMaterial3Api::class)
    fun MethodChip(label: String, selected: Boolean, onClick: () -> Unit) {
        FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
    }

    @Composable
    fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>,
                      onChange: (Float) -> Unit) {
        Column {
            Text(label, style = MaterialTheme.typography.titleSmall)
            Slider(value = value, onValueChange = onChange, valueRange = range)
        }
    }

    private suspend fun save(bmp: Bitmap) = withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "zoomfusion_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ZoomFusion")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)!!
        contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    }
}
