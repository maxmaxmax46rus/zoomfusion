package com.zoomfusion.core

import android.graphics.Bitmap
import android.graphics.Matrix
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Результат серийной съёмки: кадры + фактические множители экспозиции + метаданные цвета. */
class BurstData(
    val frames: List<RawFrame>,
    val expFactors: FloatArray,
    val noiseS: FloatArray,      // per-frame модель шума: sigma^2 = S*v + O
    val noiseO: FloatArray,
    val ccm: FloatArray?,        // 3x3 camera->sRGB или null
    val orientationDeg: Int      // SENSOR_ORIENTATION
)

object Pipeline {

    suspend fun process(
        data: BurstData, s: ProcSettings,
        progress: (String) -> Unit = {}
    ): Bitmap = withContext(Dispatchers.Default) {
        val frames = data.frames
        require(frames.size >= 3) { "Нужно минимум 3 кадра" }

        progress("Выбор опорного кадра…")
        // серый нормируем по экспозиции, чтобы выравнивание работало между брекетами
        val grays = frames.mapIndexed { i, f ->
            val g = f.halfGray()
            val inv = 1f / data.expFactors[i]
            if (inv != 1f) for (k in g.data.indices) g.data[k] *= inv
            g
        }
        // опору берём среди кадров базовой экспозиции
        val baseIdx = frames.indices.filter {
            data.expFactors[it] in 0.7f..1.4f
        }.ifEmpty { frames.indices.toList() }
        val refIdx = baseIdx.maxBy { lapVar(grays[it]) }

        progress("Выравнивание ${frames.size - 1} кадров…")
        val flows = frames.indices.map { i ->
            if (i == refIdx) null else Align.align(grays[refIdx], grays[i])
        }

        progress("Слияние (супер-резолюция)…")
        val merged = Merge.merge(data, flows, refIdx, s)

        progress("Деконволюция…")
        val sharp = Deconv.run(merged.rgb, merged.w, merged.h, merged.coverage, s.sharpness)

        progress("Цвет и тон…")
        val lin = Finish.linear(sharp, data.ccm)

        progress("Финальный ресемплинг…")
        val outW = Params.OUT_WIDTH
        val outH = (outW.toFloat() * merged.h / merged.w).toInt()
        val resized = Resample.resize(lin, merged.w, merged.h, outW, outH)
        val final = Finish.display(resized, outW, outH, s)

        val bmp = toBitmap(final, outW, outH)
        if (data.orientationDeg % 360 != 0) rotate(bmp, data.orientationDeg) else bmp
    }

    private fun rotate(src: Bitmap, deg: Int): Bitmap {
        val m = Matrix().apply { postRotate(deg.toFloat()) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun lapVar(g: Plane): Float {
        var sum = 0.0; var sum2 = 0.0; var n = 0
        for (y in 1 until g.h - 1) for (x in 1 until g.w - 1) {
            val l = 4 * g[x, y] - g[x - 1, y] - g[x + 1, y] - g[x, y - 1] - g[x, y + 1]
            sum += l; sum2 += l * l; n++
        }
        val m = sum / n
        return (sum2 / n - m * m).toFloat()
    }

    private fun toBitmap(rgb: FloatArray, w: Int, h: Int): Bitmap {
        val px = IntArray(w * h)
        for (i in 0 until w * h) {
            val r = (rgb[i * 3] * 255f + 0.5f).toInt().coerceIn(0, 255)
            val g = (rgb[i * 3 + 1] * 255f + 0.5f).toInt().coerceIn(0, 255)
            val b = (rgb[i * 3 + 2] * 255f + 0.5f).toInt().coerceIn(0, 255)
            px[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}
