package com.zoomfusion.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlin.math.*

/**
 * Мультикадровая супер-резолюция на RAW с поддержкой HDR-брекетинга.
 *
 * Кадры могут иметь разную экспозицию: перед слиянием значения нормируются
 * в линейную яркость v/e_n, а вес каждого сэмпла дополнительно умножается на
 * «правильность экспозиции» w_exp(v): клип уходит в 0, глубокие тени
 * ослабляются. Так короткая экспозиция восстанавливает света, длинная — тени,
 * и результат — линейная HDR-яркость (может превышать 1).
 */
object Merge {

    class Result(val w: Int, val h: Int, val rgb: FloatArray, val coverage: FloatArray)

    private class Kernels(val a: FloatArray, val b: FloatArray, val c: FloatArray, val w: Int, val h: Int)

    // ---- структурный тензор -> форма ядер (см. README) --------------------
    private fun buildKernels(gray: Plane, denoise: Float): Kernels {
        val w = gray.w; val h = gray.h
        val gx = FloatArray(w * h); val gy = FloatArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            gx[y * w + x] = ((gray[x + 1, y - 1] + 2 * gray[x + 1, y] + gray[x + 1, y + 1]) -
                             (gray[x - 1, y - 1] + 2 * gray[x - 1, y] + gray[x - 1, y + 1])) * 0.25f
            gy[y * w + x] = ((gray[x - 1, y + 1] + 2 * gray[x, y + 1] + gray[x + 1, y + 1]) -
                             (gray[x - 1, y - 1] + 2 * gray[x, y - 1] + gray[x + 1, y - 1])) * 0.25f
        }
        val txx = FloatArray(w * h); val txy = FloatArray(w * h); val tyy = FloatArray(w * h)
        for (i in 0 until w * h) { txx[i] = gx[i] * gx[i]; txy[i] = gx[i] * gy[i]; tyy[i] = gy[i] * gy[i] }
        boxBlur5(txx, w, h); boxBlur5(txy, w, h); boxBlur5(tyy, w, h)

        val kFlat = Params.K_FLAT * (0.4f + 1.6f * denoise)   // слайдер шумодава
        val a = FloatArray(w * h); val b = FloatArray(w * h); val c = FloatArray(w * h)
        for (i in 0 until w * h) {
            val axx = txx[i]; val bxy = txy[i]; val cyy = tyy[i]
            val tr = axx + cyy
            val d = sqrt((axx - cyy) * (axx - cyy) + 4 * bxy * bxy)
            val l1 = 0.5f * (tr + d); val l2 = max(0f, 0.5f * (tr - d))
            val coh = (l1 - l2) / (l1 + l2 + 1e-8f)
            val edge = sqrt(l1)
            var k1 = Params.K_BASE / (1f + Params.K_EDGE * edge)
            var k2 = k1 * (1f + Params.K_ANISO * coh)
            if (edge < 0.02f) { k1 = Params.K_BASE * (1f + kFlat); k2 = k1 }
            k1 = k1.coerceIn(Params.K_MIN, Params.K_MAX)
            k2 = k2.coerceIn(Params.K_MIN, Params.K_MAX)
            val theta = 0.5f * atan2(2 * bxy, axx - cyy)
            val ct = cos(theta); val st = sin(theta)
            val i1 = 1f / (k1 * k1); val i2 = 1f / (k2 * k2)
            a[i] = ct * ct * i1 + st * st * i2
            c[i] = st * st * i1 + ct * ct * i2
            b[i] = ct * st * (i1 - i2)
        }
        return Kernels(a, b, c, w, h)
    }

    private fun boxBlur5(d: FloatArray, w: Int, h: Int) {
        val tmp = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            for (k in -2..2) s += d[y * w + (x + k).coerceIn(0, w - 1)]
            tmp[y * w + x] = s / 5f
        }
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            for (k in -2..2) s += tmp[((y + k).coerceIn(0, h - 1)) * w + x]
            d[y * w + x] = s / 5f
        }
    }

    private fun quickDemosaic(f: RawFrame): Array<Plane> {
        val w = f.w; val h = f.h
        val out = Array(3) { FloatArray(w * h) }
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val c = f.channelAt(x, y); val v = f.data[y * w + x]
            out[c][y * w + x] = v
            for (cc in 0..2) if (cc != c) {
                var s = 0f; var n = 0
                for (dy in -1..1) for (dx in -1..1) {
                    if (f.channelAt(x + dx, y + dy) == cc) { s += f.data[(y + dy) * w + x + dx]; n++ }
                }
                out[cc][y * w + x] = if (n > 0) s / n else v
            }
        }
        return arrayOf(Plane(w, h, out[0]), Plane(w, h, out[1]), Plane(w, h, out[2]))
    }

    /** Вес кадра по покрытию фазового пространства (см. README). */
    private fun phaseWeights(flows: List<Flow?>): FloatArray {
        val phx = FloatArray(flows.size); val phy = FloatArray(flows.size)
        for (i in flows.indices) {
            val f = flows[i]
            phx[i] = if (f == null) 0f else ((f.dx.average().toFloat() % 1f) + 1f) % 1f
            phy[i] = if (f == null) 0f else ((f.dy.average().toFloat() % 1f) + 1f) % 1f
        }
        val w = FloatArray(flows.size)
        for (i in w.indices) {
            var dens = 0f
            for (j in w.indices) if (j != i) {
                var dx = abs(phx[i] - phx[j]); if (dx > 0.5f) dx = 1f - dx
                var dy = abs(phy[i] - phy[j]); if (dy > 0.5f) dy = 1f - dy
                dens += exp(-(dx * dx + dy * dy) / 0.02f)
            }
            w[i] = 1f / (1f + 0.5f * dens)
        }
        val m = w.max(); for (i in w.indices) w[i] = 0.4f + 0.6f * w[i] / m
        return w
    }

    /** «Правильность экспозиции» сырого значения: клип -> 0, шумные тени ослабляются. */
    private fun wExp(v: Float): Float {
        val lo = smooth(0.004f, 0.03f, v)
        val hi = 1f - smooth(0.86f, 0.985f, v)
        return lo * hi
    }
    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3 - 2 * t)
    }

    /**
     * @param expFactors фактический множитель экспозиции каждого кадра
     *                   относительно базовой (1.0 = опорный брекет)
     */
    suspend fun merge(
        data: BurstData,
        flows: List<Flow?>, refIdx: Int, s: ProcSettings
    ): Result = coroutineScope {
        val frames = data.frames
        val expFactors = data.expFactors
        val nS = data.noiseS
        val nO = data.noiseO
        val ref = frames[refIdx]
        val refE = expFactors[refIdx]
        val scale = min(2.5f, max(1.0f, 2200f / ref.w))   // адаптивный апскейл сетки
        val ow = (ref.w * scale).toInt(); val oh = (ref.h * scale).toInt()
        val rgb = FloatArray(ow * oh * 3)
        val cov = FloatArray(ow * oh)

        val refRGB = quickDemosaic(ref)
        val kern = buildKernels(Merge.luma(refRGB), s.denoise)
        val phaseW = phaseWeights(flows)
        val alignW = FloatArray(frames.size) { i ->
            val f = flows[i]; if (f == null) 1f else exp(-f.meanErr / 0.05f).coerceIn(0.2f, 1f)
        }
        val r = Params.GATHER_R
        val nu = Params.NU
        val isMean = s.method == MergeMethod.ROBUST_MEAN
        val isMedian = s.method == MergeMethod.MEDIAN
        val iso = 1f / (0.7f * 0.7f)   // изотропное ядро для ROBUST_MEAN

        val rows = (0 until oh).chunked(max(1, oh / Runtime.getRuntime().availableProcessors()))
        rows.map { chunk ->
            async(Dispatchers.Default) {
                val medBuf = FloatArray(frames.size)
                for (oy in chunk) for (ox in 0 until ow) {
                    val rx = ox / scale; val ry = oy / scale
                    val kx = rx.coerceIn(0f, (kern.w - 1).toFloat())
                    val ky = ry.coerceIn(0f, (kern.h - 1).toFloat())
                    val ki = ky.toInt() * kern.w + kx.toInt()
                    val A = if (isMean) iso else kern.a[ki]
                    val B = if (isMean) 0f else kern.b[ki]
                    val C = if (isMean) iso else kern.c[ki]

                    val o = (oy * ow + ox) * 3
                    if (isMedian) {
                        var minCnt = Float.MAX_VALUE
                        for (ch in 0..2) {
                            var cnt = 0
                            for (n in frames.indices) {
                                val fr = frames[n]; val e = expFactors[n]
                                var px = rx; var py = ry
                                if (n != refIdx) {
                                    val fl = flows[n] ?: continue
                                    val (fx, fy) = fl.flowAtRaw(rx, ry); px += fx; py += fy
                                }
                                if (px < 1f || py < 1f || px > fr.w - 2f || py > fr.h - 2f) continue
                                // ближайший сайт нужного канала
                                var bd = 4f; var bv = -1f
                                for (sy in floor(py - 1).toInt()..ceil(py + 1).toInt())
                                    for (sx in floor(px - 1).toInt()..ceil(px + 1).toInt()) {
                                        if (sx < 0 || sy < 0 || sx >= fr.w || sy >= fr.h) continue
                                        if (fr.channelAt(sx, sy) != ch) continue
                                        val d2 = (sx - px) * (sx - px) + (sy - py) * (sy - py)
                                        if (d2 < bd) { bd = d2; bv = fr.data[sy * fr.w + sx] }
                                    }
                                if (bv >= 0f && wExp(bv) > 0.3f) { medBuf[cnt++] = bv / e * refE }
                            }
                            rgb[o + ch] = if (cnt > 0) {
                                java.util.Arrays.sort(medBuf, 0, cnt); medBuf[cnt / 2]
                            } else refRGB[ch].bilinear(rx, ry)
                            if (cnt.toFloat() < minCnt) minCnt = cnt.toFloat()
                        }
                        cov[oy * ow + ox] = minCnt
                        continue
                    }

                    val accV = floatArrayOf(0f, 0f, 0f)
                    val accW = floatArrayOf(0f, 0f, 0f)
                    for (n in frames.indices) {
                        val fr = frames[n]; val e = expFactors[n]
                        var px = rx; var py = ry
                        if (n != refIdx) {
                            val fl = flows[n] ?: continue
                            val (fx, fy) = fl.flowAtRaw(rx, ry); px += fx; py += fy
                        }
                        if (px < 1f || py < 1f || px > fr.w - 2f || py > fr.h - 2f) continue
                        val wFrame = phaseW[n] * alignW[n]
                        val x0 = floor(px - r).toInt(); val x1 = ceil(px + r).toInt()
                        val y0 = floor(py - r).toInt(); val y1 = ceil(py + r).toInt()
                        for (sy in y0..y1) for (sx in x0..x1) {
                            if (sx < 0 || sy < 0 || sx >= fr.w || sy >= fr.h) continue
                            val dx = sx - px; val dy = sy - py
                            val q = A * dx * dx + 2 * B * dx * dy + C * dy * dy
                            if (q > 8f) continue
                            val ch = fr.channelAt(sx, sy)
                            val vRaw = fr.data[sy * fr.w + sx]
                            val we = wExp(vRaw); if (we < 1e-3f) continue
                            val v = vRaw / e * refE                     // линейная яркость
                            val pred = refRGB[ch].bilinear(rx, ry)
                            val sig2 = 2f * (nS[n] * max(vRaw, 1e-4f) + nO[n]) * (refE / e) * (refE / e)
                            val r2 = (v - pred) * (v - pred) / sig2
                            val rho = (nu + 1f) / (nu + r2)
                            val wgt = exp(-0.5f * q) * rho * wFrame * we
                            accV[ch] += wgt * v; accW[ch] += wgt
                        }
                    }
                    var minW = Float.MAX_VALUE
                    for (ch in 0..2) {
                        rgb[o + ch] = if (accW[ch] > 1e-6f) accV[ch] / accW[ch]
                                      else refRGB[ch].bilinear(rx, ry)
                        if (accW[ch] < minW) minW = accW[ch]
                    }
                    cov[oy * ow + ox] = minW
                }
            }
        }.forEach { it.await() }

        Result(ow, oh, rgb, cov)
    }

    fun luma(rgb: Array<Plane>): Plane {
        val w = rgb[0].w; val h = rgb[0].h
        val d = FloatArray(w * h)
        for (i in 0 until w * h)
            d[i] = 0.299f * rgb[0].data[i] + 0.587f * rgb[1].data[i] + 0.114f * rgb[2].data[i]
        return Plane(w, h, d)
    }
}
