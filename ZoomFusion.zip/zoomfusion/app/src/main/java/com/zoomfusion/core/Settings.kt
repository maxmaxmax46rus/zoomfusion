package com.zoomfusion.core

/** Метод слияния серии. */
enum class MergeMethod {
    KERNEL,       // анизотропная ядровая регрессия (макс. детализация)
    ROBUST_MEAN,  // изотропное робастное среднее (мягче, быстрее)
    MEDIAN        // медиана по кадрам (иммунитет к движению, ниже резкость)
}

/** Режим съёмки. */
enum class CamMode { PHOTO, ZOOM, HDR, NIGHT }

/**
 * Настройки обработки. Нейтральное значение слайдеров 0..1 — это 0.5.
 * zoom — итоговый эквивалент (5x оптика телевика + цифровая часть).
 */
data class ProcSettings(
    val mode: CamMode = CamMode.ZOOM,
    val zoom: Float = 30f,          // 5..30
    val frames: Int = 16,           // 8..24
    val hdrStops: Int = 3,          // 1..5 брекетов экспозиции
    val evComp: Float = 0f,         // -2..+2 EV
    val denoise: Float = 0.5f,      // 0..1
    val sharpness: Float = 0.5f,    // 0..1
    val contrast: Float = 0.5f,     // 0..1
    val saturation: Float = 0.5f,   // 0..1
    val method: MergeMethod = MergeMethod.KERNEL,
)
