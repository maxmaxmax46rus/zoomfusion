package com.zoomfusion.core

import kotlin.math.abs

/**
 * Плотное (по тайлам) поле сдвигов alt -> ref на полусетке серого.
 * Запрос flowAt() даёт билинейно интерполированный сдвиг в координатах RAW
 * (умножение на 2 внутри).
 */
class Flow(val tw: Int, val th: Int, val tile: Int,
           val dx: FloatArray, val dy: FloatArray, val err: FloatArray) {
    val meanErr: Float get() = err.average().toFloat()

    /** Сдвиг в RAW-координатах для точки (rx,ry) RAW-сетки кропа. */
    fun flowAtRaw(rx: Float, ry: Float): Pair<Float, Float> {
        val gx = rx * 0.5f / tile - 0.5f
        val gy = ry * 0.5f / tile - 0.5f
        val x0 = gx.toInt().coerceIn(0, tw - 2); val y0 = gy.toInt().coerceIn(0, th - 2)
        val ax = (gx - x0).coerceIn(0f, 1f); val ay = (gy - y0).coerceIn(0f, 1f)
        fun lerp(a: FloatArray): Float {
            val p00 = a[y0 * tw + x0]; val p10 = a[y0 * tw + x0 + 1]
            val p01 = a[(y0 + 1) * tw + x0]; val p11 = a[(y0 + 1) * tw + x0 + 1]
            return (p00 * (1 - ax) + p10 * ax) * (1 - ay) + (p01 * (1 - ax) + p11 * ax) * ay
        }
        return Pair(lerp(dx) * 2f, lerp(dy) * 2f)
    }
}

object Align {

    /** Гауссова пирамида: лёгкий блюр 1-2-1 и децимация 2x. */
    fun pyramid(src: Plane, levels: Int): List<Plane> {
        val pyr = ArrayList<Plane>(levels); pyr.add(src)
        var cur = src
        repeat(levels - 1) {
            val nw = cur.w / 2; val nh = cur.h / 2
            val d = FloatArray(nw * nh)
            for (j in 0 until nh) for (i in 0 until nw) {
                val x = i * 2; val y = j * 2
                var s = 0f
                for (dy in -1..1) for (dx in -1..1) {
                    val xx = (x + dx).coerceIn(0, cur.w - 1)
                    val yy = (y + dy).coerceIn(0, cur.h - 1)
                    val wgt = (2 - abs(dx)) * (2 - abs(dy)) // ядро 1-2-1 ⊗ 1-2-1
                    s += cur[xx, yy] * wgt
                }
                d[j * nw + i] = s / 16f
            }
            cur = Plane(nw, nh, d); pyr.add(cur)
        }
        return pyr.reversed() // от грубого к точному
    }

    /**
     * Иерархический блочный поиск L1 + субпиксель:
     * δ = ½·(c₋₁−c₊₁)/(c₋₁−2c₀+c₊₁) по каждой оси (аппроксимация параболой).
     */
    fun align(ref: Plane, alt: Plane): Flow {
        val refPyr = pyramid(ref, Params.PYR_LEVELS)
        val altPyr = pyramid(alt, Params.PYR_LEVELS)
        var fdx: FloatArray? = null; var fdy: FloatArray? = null
        var ptw = 0; var pth = 0
        var res: Flow? = null

        for (lvl in refPyr.indices) {
            val r = refPyr[lvl]; val a = altPyr[lvl]
            val tile = Params.TILE
            val tw = maxOf(1, r.w / tile); val th = maxOf(1, r.h / tile)
            val dx = FloatArray(tw * th); val dy = FloatArray(tw * th)
            val er = FloatArray(tw * th)

            for (tj in 0 until th) for (ti in 0 until tw) {
                // инициализация с грубого уровня
                var initX = 0f; var initY = 0f
                if (fdx != null) {
                    val pi = (ti * ptw / tw).coerceIn(0, ptw - 1)
                    val pj = (tj * pth / th).coerceIn(0, pth - 1)
                    initX = fdx!![pj * ptw + pi] * 2f; initY = fdy!![pj * ptw + pi] * 2f
                }
                val ox = ti * tile; val oy = tj * tile
                var best = Float.MAX_VALUE; var bx = 0; var by = 0
                val ix = initX.toInt(); val iy = initY.toInt()
                val costs = HashMap<Long, Float>()
                fun cost(sx: Int, sy: Int): Float {
                    val key = (sx.toLong() shl 32) xor (sy.toLong() and 0xffffffffL)
                    costs[key]?.let { return it }
                    var c = 0f; var n = 0
                    var y = 0
                    while (y < tile) {
                        var x = 0
                        while (x < tile) {
                            val rx = ox + x; val ry = oy + y
                            val ax2 = rx + sx; val ay2 = ry + sy
                            if (rx < r.w && ry < r.h && ax2 in 0 until a.w && ay2 in 0 until a.h) {
                                c += abs(r[rx, ry] - a[ax2, ay2]); n++
                            }
                            x += 2 // прореживание x2 для скорости
                        }
                        y += 2
                    }
                    val v = if (n > 0) c / n else Float.MAX_VALUE
                    costs[key] = v; return v
                }
                for (sy in iy - Params.SEARCH..iy + Params.SEARCH)
                    for (sx in ix - Params.SEARCH..ix + Params.SEARCH) {
                        val c = cost(sx, sy)
                        if (c < best) { best = c; bx = sx; by = sy }
                    }
                // субпиксельная квадратичная аппроксимация на 1D-сечениях
                var sub = 0f to 0f
                if (lvl == refPyr.size - 1) {
                    val c0 = best
                    val cxm = cost(bx - 1, by); val cxp = cost(bx + 1, by)
                    val cym = cost(bx, by - 1); val cyp = cost(bx, by + 1)
                    val ddx = cxm - 2 * c0 + cxp
                    val ddy = cym - 2 * c0 + cyp
                    val sx = if (ddx > 1e-9f) (0.5f * (cxm - cxp) / ddx).coerceIn(-0.5f, 0.5f) else 0f
                    val sy = if (ddy > 1e-9f) (0.5f * (cym - cyp) / ddy).coerceIn(-0.5f, 0.5f) else 0f
                    sub = sx to sy
                }
                dx[tj * tw + ti] = bx + sub.first
                dy[tj * tw + ti] = by + sub.second
                er[tj * tw + ti] = best
            }
            fdx = dx; fdy = dy; ptw = tw; pth = th
            res = Flow(tw, th, tile, dx, dy, er)
        }
        return res!!
    }
}
