package com.zoomfusion.core

import android.graphics.Rect
import android.media.Image

/** Настройки пайплайна. Единицы ядер — пиксели RAW-сетки. */
object Params {
    const val FRAMES = 16            // размер серии
    const val SCALE = 2.0f           // апскейл сетки слияния относительно кропа
    const val K_BASE = 0.9f          // базовый радиус ядра
    const val K_EDGE = 4.0f          // сжатие поперёк края
    const val K_ANISO = 2.5f         // вытягивание вдоль края
    const val K_FLAT = 1.2f          // расширение в плоских зонах (шумодав)
    const val K_MIN = 0.35f
    const val K_MAX = 2.2f
    const val NU = 4.0f              // степени свободы Student-t
    const val NOISE_S = 2.0e-4f      // sigma^2 = S*v + O (нормированные значения)
    const val NOISE_O = 1.0e-6f
    const val GATHER_R = 1.6f        // радиус сбора сэмплов, RAW px
    const val PSF_SIGMA = 1.3f       // σ PSF деконволюции (в пикселях выходной сетки)
    const val RL_ITERS = 10
    const val TILE = 16              // тайл выравнивания (на полусетке серого)
    const val SEARCH = 4             // радиус поиска на уровень пирамиды
    const val PYR_LEVELS = 4
    const val CROP_MARGIN = 1.35f    // запас кропа под сдвиги кадров
    const val DIGITAL_FACTOR = 6.0f  // 5x оптика * 6 = 30x
    const val OUT_WIDTH = 2048       // ширина финального кадра
}

/**
 * Один RAW-кадр: нормированные [0..1] значения после вычитания чёрного уровня
 * и баланса белого. CFA хранится как фаза (dx,dy) красного пикселя.
 */
class RawFrame(
    val w: Int, val h: Int,
    val data: FloatArray,      // w*h, Bayer-мозаика
    val redX: Int, val redY: Int   // фаза R в квадрате 2x2 (RGGB -> 0,0)
) {
    /** Канал Bayer-сайта: 0=R, 1=G, 2=B */
    fun channelAt(x: Int, y: Int): Int {
        val px = (x + redX) and 1; val py = (y + redY) and 1
        return if (px == 0 && py == 0) 0 else if (px == 1 && py == 1) 2 else 1
    }

    /** Полуразрешённый серый: сумма квадрата 2x2 — быстрый и WB-сбалансированный. */
    fun halfGray(): Plane {
        val gw = w / 2; val gh = h / 2
        val g = FloatArray(gw * gh)
        for (j in 0 until gh) for (i in 0 until gw) {
            val x = i * 2; val y = j * 2
            g[j * gw + i] = 0.25f * (data[y * w + x] + data[y * w + x + 1] +
                    data[(y + 1) * w + x] + data[(y + 1) * w + x + 1])
        }
        return Plane(gw, gh, g)
    }

    companion object {
        /**
         * Копирует ROI из Image(RAW_SENSOR) сразу в память и закрывает не здесь —
         * вызывающий обязан закрыть Image быстро (память!). Кроп выравнивается
         * по чётным координатам, чтобы сохранить фазу CFA.
         */
        fun fromImageCrop(
            img: Image, crop: Rect,
            blackLevel: FloatArray,          // per-CFA-site, порядок как в SENSOR_BLACK_LEVEL_PATTERN
            whiteLevel: Float,
            wbGains: FloatArray,             // R, G_even, G_odd, B
            cfa: Int                         // CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT
        ): RawFrame {
            val plane = img.planes[0]
            // RAW16 — little-endian; ByteBuffer по умолчанию big-endian
            val buf = plane.buffer.duplicate().order(java.nio.ByteOrder.LITTLE_ENDIAN)
            val rowStride = plane.rowStride
            val left = crop.left and 1.inv(); val top = crop.top and 1.inv()
            val cw = crop.width() and 1.inv(); val ch = crop.height() and 1.inv()
            val out = FloatArray(cw * ch)
            // Фаза красного по CFA: RGGB(0)->0,0 GRBG(1)->1,0 GBRG(2)->0,1 BGGR(3)->1,1
            val redX = if (cfa == 1 || cfa == 3) 1 else 0
            val redY = if (cfa == 2 || cfa == 3) 1 else 0
            val inv = 1f / whiteLevel
            for (y in 0 until ch) {
                val srcRow = (top + y) * rowStride + left * 2
                for (x in 0 until cw) {
                    val v = (buf.getShort(srcRow + x * 2).toInt() and 0xFFFF).toFloat()
                    // индекс сайта в квадрате 2x2 для чёрного уровня и WB
                    val sx = (x + redX) and 1; val sy = (y + redY) and 1
                    val site = sy * 2 + sx // 0=R 1=Gr 2=Gb 3=B при redX=redY=0
                    val bl = blackLevel[((top + y) and 1) * 2 + ((left + x) and 1)]
                    val gain = when (site) { 0 -> wbGains[0]; 1 -> wbGains[1]; 2 -> wbGains[2]; else -> wbGains[3] }
                    out[y * cw + x] = (((v - bl) * inv).coerceIn(0f, 1f)) * gain
                }
            }
            return RawFrame(cw, ch, out, redX, redY)
        }
    }
}

/** Простая float-плоскость. */
class Plane(val w: Int, val h: Int, val data: FloatArray) {
    operator fun get(x: Int, y: Int) = data[y * w + x]
    fun bilinear(fx: Float, fy: Float): Float {
        val x0 = fx.toInt().coerceIn(0, w - 2); val y0 = fy.toInt().coerceIn(0, h - 2)
        val ax = (fx - x0).coerceIn(0f, 1f); val ay = (fy - y0).coerceIn(0f, 1f)
        val p00 = data[y0 * w + x0]; val p10 = data[y0 * w + x0 + 1]
        val p01 = data[(y0 + 1) * w + x0]; val p11 = data[(y0 + 1) * w + x0 + 1]
        return (p00 * (1 - ax) + p10 * ax) * (1 - ay) + (p01 * (1 - ax) + p11 * ax) * ay
    }
}
