package com.zoomfusion.camera

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.Rect
import android.hardware.camera2.*
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import com.zoomfusion.core.BurstData
import com.zoomfusion.core.CamMode
import com.zoomfusion.core.Params
import com.zoomfusion.core.ProcSettings
import com.zoomfusion.core.RawFrame
import kotlinx.coroutines.CompletableDeferred
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Серийная съёмка RAW с HDR-брекетингом.
 * Телевик подключается пином RAW-потока к физическому ID (открывать напрямую нельзя),
 * при отказе — fallback на главный сенсор.
 */
class BurstCaptureController(private val context: Context) {

    private val TAG = "ZoomFusion"
    private val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val thread = HandlerThread("camera").apply { start() }
    private val handler = Handler(thread.looper)

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var previewSurface: Surface? = null
    private var previewZoom = 5f

    lateinit var chars: CameraCharacteristics; private set
    lateinit var rawChars: CameraCharacteristics; private set
    var cameraId: String = ""; private set
    private var physicalRawId: String? = null
    var isTele = false; private set

    private val oisAvailable: Boolean
        get() = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
            ?.contains(CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON) == true

    /** Оптическая база RAW-сенсора: 5x у телевика, 1x у главного. */
    val opticalBase get() = if (isTele) 5f else 1f
    private val logicalPreview get() = physicalRawId != null || !isTele

    fun pickCamera(): String {
        class Cand(val openId: String, val physId: String?, val ch: CameraCharacteristics, val focal: Float)
        val cands = ArrayList<Cand>()
        for (id in manager.cameraIdList) {
            val c = runCatching { manager.getCameraCharacteristics(id) }.getOrNull() ?: continue
            if (c.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) continue
            val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: continue
            val focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.maxOrNull() ?: 0f
            if (caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW))
                cands += Cand(id, null, c, focal)
            if (caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA)) {
                for (pid in c.physicalCameraIds) {
                    val pc = runCatching { manager.getCameraCharacteristics(pid) }.getOrNull() ?: continue
                    val pcaps = pc.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: continue
                    if (!pcaps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)) continue
                    val pf = pc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.maxOrNull() ?: continue
                    cands += Cand(id, pid, pc, pf)
                }
            }
        }
        require(cands.isNotEmpty()) { "Нет задней камеры с поддержкой RAW" }
        val best = cands.maxBy { it.focal }
        cameraId = best.openId
        physicalRawId = best.physId
        chars = manager.getCameraCharacteristics(cameraId)
        rawChars = best.ch
        isTele = best.focal > 8f
        Log.i(TAG, "open=$cameraId physRaw=$physicalRawId focal=${best.focal} tele=$isTele")
        return cameraId
    }

    @SuppressLint("MissingPermission")
    suspend fun open(preview: Surface) {
        previewSurface = preview
        pickCamera()

        val opened = CompletableDeferred<CameraDevice>()
        manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
            override fun onOpened(d: CameraDevice) { opened.complete(d) }
            override fun onDisconnected(d: CameraDevice) { d.close() }
            override fun onError(d: CameraDevice, e: Int) {
                opened.completeExceptionally(RuntimeException("Camera error $e"))
            }
        }, handler)
        device = opened.await()

        session = try {
            createSession(pinPhysical = true)
        } catch (e: Exception) {
            Log.w(TAG, "Физический RAW-поток недоступен (${e.message}), fallback на главный сенсор")
            physicalRawId = null
            rawChars = chars
            isTele = false
            createSession(pinPhysical = false)
        }
        startPreview()
    }

    private suspend fun createSession(pinPhysical: Boolean): CameraCaptureSession {
        val dev = device!!
        val pv = previewSurface!!
        val rawSize = rawChars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
            .getOutputSizes(ImageFormat.RAW_SENSOR).maxBy { it.width.toLong() * it.height }
        reader?.close()
        reader = ImageReader.newInstance(rawSize.width, rawSize.height, ImageFormat.RAW_SENSOR, 6)
        val rawOut = OutputConfiguration(reader!!.surface)
        if (pinPhysical) physicalRawId?.let { rawOut.setPhysicalCameraId(it) }

        val ready = CompletableDeferred<CameraCaptureSession>()
        dev.createCaptureSession(SessionConfiguration(
            SessionConfiguration.SESSION_REGULAR,
            listOf(OutputConfiguration(pv), rawOut),
            { r -> handler.post(r) },
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) { ready.complete(s) }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    ready.completeExceptionally(RuntimeException("Session config failed"))
                }
            }))
        return ready.await()
    }

    /** Живой зум превью под выбранный итоговый зум. */
    fun setPreviewZoom(totalZoom: Float) {
        previewZoom = totalZoom
        runCatching { startPreview() }
    }

    private fun previewZoomRatio(): Float {
        val range = chars.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
        val want = if (logicalPreview) previewZoom else previewZoom / 5f
        return want.coerceIn(range?.lower ?: 1f, range?.upper ?: want)
    }

    private fun startPreview() {
        val dev = device ?: return
        val pv = previewSurface ?: return
        val prev = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
            addTarget(pv)
            set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            set(CaptureRequest.CONTROL_ZOOM_RATIO, previewZoomRatio())
            if (oisAvailable) set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
        }
        session!!.setRepeatingRequest(prev.build(), null, handler)
    }

    suspend fun captureBurst(s: ProcSettings): BurstData {
        val dev = device ?: error("Камера не открыта")
        val ses = session ?: error("Нет сессии")
        val rdr = reader ?: error("Нет ридера")
        val pv = previewSurface ?: error("Нет превью")

        // 1) лочим AE/AF и читаем базовые значения
        val probe = CompletableDeferred<TotalCaptureResult>()
        val lockReq = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
            addTarget(pv)
            set(CaptureRequest.CONTROL_AE_LOCK, true)
            set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START)
            set(CaptureRequest.CONTROL_ZOOM_RATIO, previewZoomRatio())
        }
        ses.capture(lockReq.build(), object : CameraCaptureSession.CaptureCallback() {
            override fun onCaptureCompleted(sn: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
                probe.complete(res)
            }
        }, handler)
        val aeRes = probe.await()
        val baseExp = aeRes.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: 8_000_000L
        val baseIso = (aeRes.get(CaptureResult.SENSOR_SENSITIVITY) ?: 400)
        val isoMax = rawChars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)?.upper ?: 3200
        val isoMin = rawChars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)?.lower ?: 50
        val expCap = if (s.mode == CamMode.NIGHT) 40_000_000L else 12_000_000L
        val evMul = 2.0.pow(s.evComp.toDouble())

        // 2) план брекетов: множители экспозиции с шагом 1.5 EV вокруг базы
        val stops = if (s.mode == CamMode.HDR) s.hdrStops.coerceIn(1, 5) else 1
        val perBracket = max(4, s.frames / stops)
        val prof = aeRes.get(CaptureResult.SENSOR_NOISE_PROFILE)
        val profS = prof?.map { it.first }?.average()?.toFloat() ?: Params.NOISE_S
        val profO = prof?.map { it.second }?.average()?.toFloat() ?: Params.NOISE_O
        data class Shot(val exp: Long, val iso: Int, val factor: Float)
        val shots = ArrayList<Shot>(stops * perBracket)
        for (b in 0 until stops) {
            val wantMul = 2.0.pow(((b - (stops - 1) / 2.0) * 1.5)) * evMul
            var exp = (baseExp * wantMul).toLong()
            var iso = baseIso
            if (exp > expCap) { iso = (baseIso * exp.toDouble() / expCap).roundToInt(); exp = expCap }
            iso = iso.coerceIn(isoMin, isoMax)
            val actual = (exp.toDouble() * iso) / (baseExp.toDouble() * baseIso) / evMul
            repeat(perBracket) { shots += Shot(exp, iso, actual.toFloat()) }
        }

        // 3) метаданные распаковки и цвета — от сенсора, дающего RAW
        val active = rawChars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)!!
        val white = rawChars.get(CameraCharacteristics.SENSOR_INFO_WHITE_LEVEL)?.toFloat() ?: 1023f
        val blp = rawChars.get(CameraCharacteristics.SENSOR_BLACK_LEVEL_PATTERN)
        val black = FloatArray(4) { blp?.getOffsetForIndex(it % 2, it / 2)?.toFloat() ?: 64f }
        val cfa = rawChars.get(CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT) ?: 0
        val gains = aeRes.get(CaptureResult.COLOR_CORRECTION_GAINS)
        val wb = floatArrayOf(
            gains?.red ?: 2.0f, gains?.greenEven ?: 1.0f,
            gains?.greenOdd ?: 1.0f, gains?.blue ?: 1.6f
        )
        val cst = aeRes.get(CaptureResult.COLOR_CORRECTION_TRANSFORM)
        val ccm = cst?.let { t ->
            FloatArray(9) { i -> t.getElement(i % 3, i / 3).toFloat() }
        }
        val orientation = rawChars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90

        // ROI: центр, поле = 1/цифровой множитель + запас
        val digital = max(1f, s.zoom / opticalBase)
        val cw = ((active.width() / digital) * Params.CROP_MARGIN).toInt()
            .coerceAtMost(active.width()) and 1.inv()
        val chh = ((active.height() / digital) * Params.CROP_MARGIN).toInt()
            .coerceAtMost(active.height()) and 1.inv()
        val crop = Rect(
            (active.width() - cw) / 2 and 1.inv(), (active.height() - chh) / 2 and 1.inv(), 0, 0
        ).apply { right = left + cw; bottom = top + chh }

        // 4) серия
        val frames = ArrayList<RawFrame>(shots.size)
        val done = CompletableDeferred<Unit>()
        rdr.setOnImageAvailableListener({ r ->
            val img = r.acquireNextImage() ?: return@setOnImageAvailableListener
            try {
                frames += RawFrame.fromImageCrop(img, crop, black, white, wb, cfa)
            } finally { img.close() }
            if (frames.size >= shots.size && !done.isCompleted) done.complete(Unit)
        }, handler)

        val burst = shots.map { sh ->
            dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(rdr.surface)
                set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                set(CaptureRequest.SENSOR_EXPOSURE_TIME, sh.exp)
                set(CaptureRequest.SENSOR_SENSITIVITY, sh.iso)
                set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_OFF)
                set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_OFF)
                if (oisAvailable) set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                    CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
                set(CaptureRequest.CONTROL_ZOOM_RATIO, previewZoomRatio())
            }.build()
        }
        ses.captureBurst(burst, null, handler)
        done.await()
        startPreview()

        // порядок кадров = порядок запросов
        val factors = FloatArray(frames.size) { i -> shots[i.coerceIn(shots.indices)].factor }
        val base = baseIso.coerceAtLeast(1).toFloat()
        val noiseS = FloatArray(frames.size) { i ->
            profS * (shots[i.coerceIn(shots.indices)].iso / base) }
        val noiseO = FloatArray(frames.size) { i ->
            val r = shots[i.coerceIn(shots.indices)].iso / base; profO * r * r }
        return BurstData(frames, factors, noiseS, noiseO, ccm, orientation)
    }

    fun close() {
        session?.close(); device?.close(); reader?.close()
        thread.quitSafely()
    }
}
